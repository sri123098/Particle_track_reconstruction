def save_checkpoint(epoch, model, optimizer, filename):
    state = {
        'epoch': epoch,
        'state_dict': model.state_dict(),
        'optimizer': optimizer.state_dict()
    }
    torch.save(state, filename)

def loss_function(x, y):
    loss = nn.L1Loss(size_average=True).cuda()
    return loss(x, y)

def train(train_loader, model, optimizer):
    # switch to train mode
    model.train()
    
    train_loss = 0
    num_batch = 0
    for i, (input, target) in enumerate(train_loader):
        img1 = Variable(input).cuda()
        img2 = Variable(target).cuda()
        
        model.zero_grad()
        output = model(img1)
        loss = loss_function(output, img2)
        # Back propagation
        loss.backward()
        optimizer.step()
        # log
        train_loss += loss.data.item()
        num_batch += 1
    print("Training Loss:")
    print("    U-Net loss:\t\t{:.6f}".format(train_loss/num_batch))

def validate(val_loader, model):
    # switch to evaluate mode
    model.eval()
    
    val_loss = 0
    num_batch = 0
    for i, (input, target) in enumerate(val_loader):
        img1 = Variable(input).cuda()
        img2 = Variable(target).cuda()
        
        output = model(img1)
        loss = loss_function(output, img2)
        # log
        val_loss += loss.data.item()
        num_batch += 1
    print("Validation Loss:")
    print("    U-Net loss:\t\t{:.6f}".format(val_loss/num_batch))

