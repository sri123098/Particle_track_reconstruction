#!/usr/bin/env python
# coding: utf-8

# In[1]:


import torch
import torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable,Function
import torch.utils.data
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import RandomSampler, SequentialSampler
import numpy as np
import scipy.io as sio
import time
from PIL import Image
import scipy
import random
import os.path
import pandas
import matplotlib.pyplot as plt
import pandas
import tomopy
import sys
sys.path.append('../../python')

from UNet import UNet

prefix_DATA = "../dataset/"
prefix_RESULT = "../result/"


# In[2]:


class ctDataset(Dataset):
    def __init__(self, input_list, target_list, input_transform=None, target_transform=None):
        super(ctDataset, self).__init__()
        self.input_filenames = input_list
        self.target_filenames = target_list
        
        self.input_transform = input_transform
        self.target_transform = target_transform
        
    def __getitem__(self, index):
        df1 = pandas.read_csv(prefix_DATA + self.input_filenames[index], header=None, delimiter=',')
        img1 = df1.values
        img1 = img1 / np.amax(img1)
        img1 = img1.reshape(1, img1.shape[0], img1.shape[1])
        img1 = img1.astype(np.float32)
        
        df2 = pandas.read_csv(prefix_DATA + self.target_filenames[index], header=None, delimiter=',')
        img2 = df2.values
        img2 = img2 / np.amax(img2)
        img2 = img2.reshape(1, img2.shape[0], img2.shape[1])
        img2 = img2.astype(np.float32)
        
        if self.input_transform:
            img1 = self.input_transform(img1)
            
        if self.target_transform:
            img2 = self.target_transform(img2)
        
        return img1, img2
        
    def __len__(self):
        return len(self.input_filenames)

def save_checkpoint(epoch, model, optimizer, filename):
    state = {
        'epoch': epoch,
        'state_dict': model.state_dict(),
        'optimizer': optimizer.state_dict()
    }
    torch.save(state, filename)

def loss_function(x, y):
    loss = nn.L1Loss(size_average=True).cuda()
    return loss(x, y)

def train(train_loader, model, optimizer):
    # switch to train mode
    model.train()
    
    train_loss = 0
    num_batch = 0
    for i, (input, target) in enumerate(train_loader):
        img1 = Variable(input).cuda()
        img2 = Variable(target).cuda()
        
        model.zero_grad()
        output = model(img1)
        loss = loss_function(output, img2)
        # Back propagation
        loss.backward()
        optimizer.step()
        # log
        train_loss += loss.data.item()
        num_batch += 1
    print("Training Loss:")
    print("    U-Net loss:\t\t{:.6f}".format(train_loss/num_batch))

def validate(val_loader, model):
    # switch to evaluate mode
    model.eval()
    
    val_loss = 0
    num_batch = 0
    for i, (input, target) in enumerate(val_loader):
        img1 = Variable(input).cuda()
        img2 = Variable(target).cuda()
        
        output = model(img1)
        loss = loss_function(output, img2)
        # log
        val_loss += loss.data.item()
        num_batch += 1
    print("Validation Loss:")
    print("    U-Net loss:\t\t{:.6f}".format(val_loss/num_batch))


# In[3]:


# parameter settings
batchSize = 16
epochs = 20
check_point = 3
lr = 0.0001
betas = (0.9, 0.999)

# dataset list
prefix_dataset_list = prefix_DATA + "new_dataset_list_/"
#prefix_dataset_list = prefix_DATA + "old_dataset_list/"

# create model
print('Creating model...')
model = UNet().cuda()
model_name = "U-Net"

# create optimizer
print('Creating optimizer...')
optimizer = optim.Adam(model.parameters(), lr=lr, betas=betas)

start = 0
# load saved model
if os.path.exists(prefix_RESULT + model_name+'.pth.tar'):
    print('Loading model..')
    saved_model = torch.load(prefix_RESULT + model_name+'.pth.tar')
    start = saved_model['epoch']
    model.load_state_dict(saved_model['state_dict'])
    optimizer.load_state_dict(saved_model['optimizer'])
else:
    # Training Code here
    print('Training Network...')
    # load data
    print('Creating Data Loader...')
    # data for training
    file1 = open(prefix_dataset_list + "train_input.txt", "r")
    train_input = file1.read().split('\n')
    file2 = open(prefix_dataset_list + "train_target.txt", "r")
    train_target = file2.read().split('\n')
    train_set = ctDataset(train_input, train_target)
    train_loader = DataLoader(dataset=train_set, batch_size=batchSize,
                              num_workers=4, sampler=RandomSampler(train_set), pin_memory=True)
    # data for validation
    file4 = open(prefix_dataset_list + "test_input.txt", "r")
    val_input = file4.read().split('\n')
    file5 = open(prefix_dataset_list + "test_target.txt", "r")
    val_target = file5.read().split('\n')
    val_set = ctDataset(val_input, val_target)
    val_loader = DataLoader(dataset=val_set, batch_size=batchSize,
                            num_workers=4, sampler=SequentialSampler(val_set), pin_memory=True)
    # close files
    file1.close()
    file2.close()
    file4.close()
    file5.close()
    
    for epoch in range(start, epochs):
        #adjustLR(epoch, optimizer)
        print("Epoch {} of {}".format(epoch+1, epochs))
        start_time = time.time()
        train(train_loader, model, optimizer)
        print("  training time:\t\t{:.3f}s".format(time.time()-start_time))
        start_time = time.time()
        validate(val_loader, model)
        print("  validation time:\t\t{:.3f}s".format(time.time()-start_time))
        # save network
        if epoch%check_point==0:
            print("Saving network...")
            save_checkpoint(epoch+1, model, optimizer, prefix_RESULT + model_name+"_"+str(epoch)+"_" +'.pth.tar')
        elif epoch==epochs-1:
            print("Saving network...")
            save_checkpoint(epoch+1, model, optimizer, prefix_RESULT + model_name +'.pth.tar')
    print('Training Done...')


